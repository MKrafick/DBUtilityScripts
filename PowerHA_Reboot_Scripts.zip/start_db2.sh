#!/usr/bin/ksh

###################################################################################
## Developed: September 27, 2012, V1.0                                            #
## Authorship: Michael Krafick (DBA)                                              #
##             Scott Robertson (SA)                                               #
## Purpose:                                                                       #
## This script is called by HACMP/PowerHA to start DB2 and activate databases.    #
## This is developed to work with one or many DB2 instances and databases on a    #
## single node HACMP/PowerHA configuration.                                       #
##                                                                                #
## Some logic or direct code is based off IBM's sample script:                    #
##                                          ~/sqllib/samples/hacmp/hacmp-s1.sh    #
##                                                                                #
## Use this script at your own risk, testing thoroughly in your own environment.  #
## The authors do not guarantee the script and are not responsible for any damage #
## that may be caused in your specific environment.                               #
###################################################################################

###################################################################################
## VARIABLE AND PERMISSION SETTING                                                #
###################################################################################

DB2_INSTALL=/sw/pkg/IBM/db2/
PROGRAM=${0##*/}
export PROGRAM

## Allows files written by root to be readible by instance
umask 022

## Used in determinig if INSTHOME exists or not
## typeset variable as an integer
typeset -i TRUE; TRUE=0
typeset -i FALSE; FALSE=1

## used in return code testing
## typeset variable as an integer
typeset -i RC; RC=0

###################################################################################
##  FUNCTIONS                                                                     #
###################################################################################

## FUNCTION: FIND_HOMEDIR
## Find instance home directory, called to help locate specific DB2 commands
## Code copied and manipulated from IBM DB2 sample script, hacmp-stop.sh

function find_homedir {
  typeset instname=$1	# instance userid
  INSTHOME=""		# Home dir of the instance, to be passed outside function

  /usr/sbin/lsuser ${instname} 1>/dev/null 2>/dev/null
  test $? -ne 0 && return ${FALSE}

  INSTHOME="$(/usr/sbin/lsuser -c -a home ${instname} | \
              tail -n 1 | awk -F":" '{print $NF}')"

  if [ -d ${INSTHOME} ]; then
     return ${TRUE}
  else
     return ${FALSE}
  fi
}

## FUNCTION: LIST_DATABASES
## Provide a locally catalogued databases (Indirect) for specific instance owner
## Any remotly catalogued databases (Remote) are ignored in list generation

function list_databases {
  # define local function variables
  typeset local_USERID=${1:?"missing instance owner userid"}

  /usr/bin/su - ${local_USERID} -c "db2 \"list database directory\"" |\
    grep -p "Indirect" |\
      awk '/alias/{ print $NF; }'
}

## FUNCTION: DB2_START
## Start DB2, activate databases.
## A single SQL file is generated with ACTIVATE command and executed as single UOW.

function db2_start {
  # Define local function variables
  typeset local_USERID=${1:?"missing instance owner userid"}
  typeset local_TEMPSQL=/tmp/${PROGRAM}_$$.sql
  typeset local_RC=0

  # start DB2
  /usr/bin/su - ${local_USERID} -c "db2start"

  # Removes old local_TEMPSQL, a file generated containing ACTIVATE commands
  test -f ${local_TEMPSQL} && rm ${local_TEMPSQL}

  # Build ln SQL file (local_TEMPSQL) to activate each database
  typeset local_DATABASE
  for local_DATABASE in $(list_databases ${local_USERID})
  do
    echo "activate database ${local_DATABASE};" >>${local_TEMPSQL}
  done
  echo "terminate;" >>${local_TEMPSQL}

  # Execute sql script to activate each database
  /usr/bin/su - ${local_USERID} -c "db2 -tvf ${local_TEMPSQL}"
  local_RC=$?

  # Removes newly generated local_TEMPSQL, now that we are complete
  test -f ${local_TEMPSQL} && rm ${local_TEMPSQL}

  return ${local_RC}
}

###################################################################################
## MAIN CODE EXECUION                                                             #
###################################################################################

## Search default IBM DB2 installation directores for VX.X and issue DB2ILIST to
## discover one or more instances.
## Confirm that each instance ID is a valid instance ID on server to sudo to.
## Assumptions made regarding DB2 install and naming conventions.

for VERSION_DIR in $(ls -1d ${DB2_INSTALL}/V*)
do

  # assumption made for location of db2ilist
  # ensure db2ilist is executable or skip to next VERSION_DIR in loop
  DB2_ILIST=${VERSION_DIR}/bin/db2ilist
  test -x ${DB2_ILIST} || break

  for INSTANCE_OWNER in $(${DB2_ILIST})
  do

    ## determine if valid unix user and set INSTHOME variable
    find_homedir ${INSTANCE_OWNER}
    RC=$?
    if [ ${RC} -ne 0 ]
    then
      ## not a valid unix account, skip to next INSTANCE_OWNER in loop
      echo "ERROR: invalid instance owner userid: ${INSTANCE_OWNER}"
      break
    fi

    ## Function called to start DB2 and ativate each database for one or multiple
    ## instances and databases

    db2_start ${INSTANCE_OWNER}
    RC=$?
    if [ ${RC} -ne 0 ]
    then
      ## db2_start returned a non-zero exit code, check output logs
      echo "ERROR: database start returned non-zero: ${INSTANCE_OWNER}"
      echo "ERROR: time to engage the oncall LUW DB2 DBA for assistance"
    fi

  done

done

exit 0
